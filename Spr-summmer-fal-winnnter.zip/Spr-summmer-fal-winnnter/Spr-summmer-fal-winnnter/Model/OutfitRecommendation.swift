//
//  OutfitRecommendation.swift
//  Spr-summmer-fal-winnnter
//
//  Created by Suzie Kim on 5/26/25.
//

import Foundation

struct OutfitRecommendation {
    let topImageName: String
    let bottomImageName: String

    static let mock = OutfitRecommendation(
        topImageName: "t-shirts",
        bottomImageName: "shorts"
    )
}
