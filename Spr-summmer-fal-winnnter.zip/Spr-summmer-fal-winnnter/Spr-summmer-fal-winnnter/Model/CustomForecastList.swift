//
//  DataModel.swift
//  Spr-summmer-fal-winnnter
//
//  Created by NH on 5/21/25.
//

import Foundation

struct CustomForecastList {
    let day: String
    let tempMin: Double
    let tempMax: Double
    let pop: Double
    let icon: String
}
