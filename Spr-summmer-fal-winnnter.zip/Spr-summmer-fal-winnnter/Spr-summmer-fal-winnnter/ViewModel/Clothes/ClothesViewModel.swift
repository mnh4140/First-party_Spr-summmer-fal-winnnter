//
//  ClothesViewModel.swift
//  Spr-summmer-fal-winnnter
//
//  Created by Suzie Kim on 5/26/25.
//

import Foundation
import RxSwift
import RxCocoa

final class ClothesViewModel {
    
    // 외부에서 온도/날씨를 받아 추천 결과를 방출
    let recommendation = BehaviorRelay<OutfitRecommendation?>(value: nil)
    
    // 외부에서 호출
    func update(temp: Double, condition: String) {
        let result = recommendClothes(temp: temp, condition: condition)
        recommendation.accept(result)
    }

    private func recommendClothes(temp: Double, condition: String) -> OutfitRecommendation {
        switch condition {
        case "Rain":
            return OutfitRecommendation(topImageName: "raincoat", bottomImageName: "rain_boots")
        case "Snow":
            return OutfitRecommendation(topImageName: "padded_coat", bottomImageName: "boots")
        default:
            switch temp {
            case ..<5:
                return OutfitRecommendation(topImageName: "thick_knit", bottomImageName: "thermal_pants")
            case 5..<15:
                return OutfitRecommendation(topImageName: "knit", bottomImageName: "pants")
            case 15..<22:
                return OutfitRecommendation(topImageName: "longsleeve", bottomImageName: "jeans")
            case 22..<28:
                return OutfitRecommendation(topImageName: "t-shirts", bottomImageName: "shorts")
            default:
                return OutfitRecommendation(topImageName: "sleeveless", bottomImageName: "linen_shorts")
            }
        }
    }
}
